Thank you for downloading our font.

You are expressly and emphatically restricted from all of the following:

1. You can�t sell the fonts of FontBD
2. You can�t upload our fonts on your website without our consent or proper legal permission.
3. You can't change any information of the fonts, sell/distribute/share as your own creation or intellectual property.
4. You can't use our fonts as webfont.

If You've purchased our font from 3rd party please share 3rd party's details with us, we will take legal step against the fraud. 